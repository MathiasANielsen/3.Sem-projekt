﻿namespace Domain
{
    public class Supplier
    {
        public int _id { get; set; }
        public string _name { get; set; }
        public string _cvrNo { get; set; }
        public string _phone { get; set; }
        public string _email { get; set; }
        public string _address { get; set; }
    }
}
