﻿namespace Domain
{
    public class ZipCity
    {
        public int _id { get; set; }
        public int _zipCode { get; set; }
        public string _city { get; set; }

    }
}
