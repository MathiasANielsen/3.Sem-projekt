﻿namespace Domain
{
    public class Employee
    {
        public int _id { get; set; }
        public string _fName { get; set; }
        public string _lName { get; set; }
        public string _username { get; set; }
        public string _password { get; set; }
        public string _salt { get; set; }
    }
}
