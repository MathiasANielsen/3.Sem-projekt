﻿namespace Domain
{
    public class OrderLineList
    {
        public int _id { get; set; }
        public int _orderLineId { get; set; }
        public int _uniqueProductId { get; set; }
    }
}
